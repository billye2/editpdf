# Handoff: EditPDF — restyled shell + empty state ("Sunny", option 1a)

## Overview
EditPDF is a desktop app for editing text inside existing PDFs: click a paragraph, type, and the
paragraph reflows to fit. This handoff covers the **app shell (window chrome, title bar, toolbar,
action bar) and the no-document-open empty state**.

The restyle brings EditPDF in line with the sibling product "PDF Page Manager / PDF Mana": light
cream canvas, white chrome, fully-rounded pill controls with a hard bottom shadow, a small candy
accent palette, and a rounded display face. It also raises hit targets and replaces jargon with
plain language so the app works for children and older adults, not just power users.

## About the Design Files
`editpdf-empty-state.html` in this bundle is a **design reference created in HTML** — a static
prototype of the intended look, not production code to copy. The task is to **recreate this design
in the target codebase's existing environment** (React/Electron, SwiftUI, Vue, etc.) using its
established component library, styling approach, and conventions. If no environment exists yet,
pick the framework most appropriate for the project and implement there.

Notes on reading the file:
- All styling is inline on the elements, on purpose (it streams). Do **not** mirror that in
  production — hoist it into the codebase's normal styling layer.
- Controls are plain `<div>`s. In production they must be real semantic controls: `<button>`,
  `<input type="checkbox">` (the "Show boxes" switch), a menu button for "Blocks", and a labelled
  drop target for the drop zone. Every control needs a focus ring and keyboard operation.
- `data-hover-style="…"` attributes record the intended `:hover` treatment for that control (the
  prototype can't express pseudo-states in plain HTML).

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, and shadows below are final; recreate them closely.
The only invented content is the sample copy. Icon glyphs in the prototype are typographic
stand-ins (`＋ − ⤓ ↺ ↻ ? Aa ▾ T ✦`) — replace each with the codebase's real icon set at the same
optical size (see Assets).

---

## Screens / Views

### 1. App shell (present in every state)

**Layout** — one vertical stack, full window width (prototype canvas 1180px, fluid in production):

| Row | Height | Background | Bottom border |
|---|---|---|---|
| Window title bar | 34px | `#F6F1E6` | 1px `rgba(46,42,38,.08)` |
| Identity / status / global actions | auto (12px v-padding, 44px controls → 68px) | `#FFFFFF` | 1px `rgba(46,42,38,.07)` |
| Document action bar | auto (12px v-padding, 46px controls → 70px) | `#FFFDF7` | **2px `#F2E7CE`** |
| Canvas | fills | `#FDF8EC` + dot grid | — |

The 2px warm `#F2E7CE` rule under the action bar is a signature of the PDF Mana style — keep it.

#### Row 1 — window title bar
- Left: three 11px circles, 8px gap, 14px inset — `#FB8B8B`, `#FCD277`, `#6FD79E`.
  On macOS use the native traffic lights instead and keep the 34px bar height.
- Then 10px gap, "EditPDF", Nunito 700 12px, `rgba(46,42,38,.45)`.

#### Row 2 — identity, status, global actions
Flex row, `align-items:center`, `gap:18px`, padding `12px 20px`.
1. **Wordmark block** (min-width 170px, column, 1px gap):
   - "EditPDF" — Baloo 2 800, 19px, line-height 1.1, `#2E2A26`
   - "Fix · Reflow · Patch · Save" — Nunito 600, 11.5px, line-height 1.2, `rgba(46,42,38,.45)`
2. **Status pill** (centered, `flex:1` spacer around it): padding `7px 16px`, radius 999px,
   background `#F7F3EA`; 9px dot `#C9C2B6` (grey = nothing open; `#6FD79E` when a document is
   loaded) + label Nunito 800 14px `rgba(46,42,38,.55)`. Copy when empty: **"Nothing open yet"**;
   when loaded: `"<filename> · <n> pages"`.
3. **Global actions** (right, 10px gap):
   - Help `?` and text-settings `Aa`: 44×44 circles, 1.5px border `rgba(46,42,38,.12)`, `#fff`,
     glyph Nunito 800 17px/15px `#6B635A`; hover `#F7F3EA`.
   - **Blocks ▾** — pill, height 44, padding `0 18px`, radius 999, 1.5px border
     `rgba(46,42,38,.12)`, `#fff`, label Nunito 800 15px `#3A3532`, caret 11px
     `rgba(46,42,38,.45)`. Opens the block/structure menu.
   - **Save PDF** — primary green pill, height 44, padding `0 22px`, radius 999,
     `linear-gradient(180deg,#4FDCA2,#22C08A)`, label Nunito 800 15.5px `#fff`, leading `⤓` 16px,
     shadow `0 3px 0 #1BA377, 0 6px 14px rgba(34,192,138,.35)`.
     **Disabled in the empty state: `opacity:.45`, not clickable.**

#### Row 3 — document action bar
Flex row, `gap:12px`, padding `12px 20px`.
- **Open a PDF** — blue primary pill, height 46, padding `0 22px`, radius 999, `#3D8BFD`,
  label Nunito 800 15.5px `#fff`, leading `＋` 18px, shadow `0 3px 0 #2B6FD6, 0 6px 14px rgba(61,139,253,.30)`; hover `brightness(1.05)`.
- **Recents** — height 46, padding `0 20px`, radius 999, `#fff`, 1.5px border
  `rgba(46,42,38,.14)`, Nunito 800 15px `#3A3532`; hover `#F7F3EA`.
- **Save as…** — disabled style: `#F7F3EA`, 1.5px border `rgba(46,42,38,.09)`, text
  `rgba(46,42,38,.32)`.
- Divider — 1px × 28px `rgba(46,42,38,.12)`, 4px horizontal margin.
- **Zoom group** — one inset track: padding 5px, radius 999, `#F7F3EA`, 4px gap containing
  `−` / value / `＋`. Steppers 36×36 circles, `#fff`, Nunito 900 18px `#3A3532`,
  shadow `0 1.5px 0 rgba(46,42,38,.08)`. Value: min-width 64px, centered, Nunito 800 15px
  `#3A3532` (e.g. "125%").
- **Fit width**, **Fit page** — height 40, padding `0 16px`, radius 999, `#fff`, 1.5px border
  `rgba(46,42,38,.12)`, Nunito 800 14px `#3A3532`.
- Spacer (`flex:1`).
- **Undo / Redo** — 44×44 circles, 8px gap. Disabled: `#F7F3EA`, border
  `rgba(46,42,38,.09)`, glyph 18px `rgba(46,42,38,.30)`. Enabled: `#fff`, border
  `rgba(46,42,38,.12)`, glyph `#6B635A`.
- **Show boxes** switch (replaces the old "Debug boxes" checkbox): 46×26 track, radius 999,
  off `#E3DCCF` / on `#4FDCA2`, 3px padding, 20px white knob with
  `0 1px 2px rgba(0,0,0,.18)`; knob slides right when on. Label Nunito 700 13.5px
  `rgba(46,42,38,.55)`, 10px gap. Renamed on purpose — plainer language.

### 2. Empty state (canvas, no document open)

**Purpose:** get a file in, and in one sentence explain what makes EditPDF different (typing
reflows the paragraph).

**Layout:** canvas `#FDF8EC` with a dot grid —
`background-image: radial-gradient(rgba(46,42,38,.055) 1.4px, transparent 1.4px); background-size:22px 22px`.
Contents centered both axes, column, `gap:30px`, prototype canvas height 560px (in production the
canvas fills remaining height; keep the block vertically centered).

**a) Drop zone card** — width 660px, padding `40px 44px 44px`, radius 32px,
`3px dashed #D9CFB8`, background `rgba(255,255,255,.72)`; column, centered, `gap:24px`.
On drag-over: tint background to `#FFFDF7`, border to solid `#3D8BFD`, and scale the page-card
cluster ~1.04.

1. **Page-card cluster** — 150×104 relative box, three paper cards:
   - back-left 74×94, radius 12, `#fff`, 1.5px border `rgba(46,42,38,.12)`,
     shadow `0 6px 14px rgba(46,42,38,.10)`, `rotate(-9deg)`, at `left:0; top:8px`
   - back-right same but `#FFF6DF`, `rotate(7deg)`, at `right:0; top:4px`
   - front 74×96 at `left:38px; top:0`, `#fff`, border `rgba(46,42,38,.14)`,
     shadow `0 10px 20px rgba(46,42,38,.14)`, padding `14px 12px`, containing five 6px
     text-line bars (radius 99px, `#E7E1D6`) at widths 100/78/60/100/44% — the third bar is
     mint `#A9DFC6` to hint "this line is editable".
   - All three float: `@keyframes floaty` translateY 0 → −7px → 0, 4.4s ease-in-out infinite,
     staggered 0 / 0.3s / 0.6s, each preserving its own rotation.
     Respect `prefers-reduced-motion: reduce` — hold the cards still.
2. **Headline** — "Drop a PDF right here", Baloo 2 800, 34px, line-height 1.1, `#2E2A26`.
3. **Subhead** — "Then click any paragraph and just type. The words move over to make room —
   nothing else shifts." Nunito 600, 17px, line-height 1.5, `rgba(46,42,38,.60)`, max-width 460px,
   centered, `text-wrap:pretty`.
4. **Buttons** (row, 14px gap):
   - **Choose a file** — height 56, padding `0 30px`, radius 999, `#3D8BFD`, Nunito 800 18px
     `#fff`, leading `＋` 20px, shadow `0 4px 0 #2B6FD6, 0 10px 20px rgba(61,139,253,.28)`;
     hover `brightness(1.06)`. Opens the same file picker as "Open a PDF".
   - **Try a sample** — height 56, padding `0 28px`, radius 999, `#fff`, 2px border
     `rgba(46,42,38,.14)`, Nunito 800 17px `#3A3532`; hover `#F7F3EA`. Loads a bundled sample PDF.

**b) Capability cards** — row, 14px gap, three cards. Each: padding `14px 20px`, radius 20px,
`#fff`, 1.5px border `rgba(46,42,38,.09)`, shadow `0 2px 0 rgba(46,42,38,.05)`, 12px gap,
38×38 radius-12 icon tile + two-line text (title Nunito 800 14.5px `#2E2A26`; caption Nunito 600
12.5px `rgba(46,42,38,.50)`).

| Card | Tile bg / glyph color | Glyph | Title | Caption |
|---|---|---|---|---|
| 1 | `#DDEBFF` / `#2F6FD0` | `T` | Retype a paragraph | It reflows to fit |
| 2 | `#E7DBFF` / `#7B54D3` | `✦` | Patch scanned words | Tap a highlight to fix it |
| 3 | `#CFEEDF` / `#1E9B72` | `↺` | Undo anything | Your original stays safe |

These are informational, not buttons. If they become clickable later, give them a hover lift and
real button semantics.

---

## Interactions & Behavior
- **Open a PDF / Choose a file** → native file picker, `.pdf` only. Reject other types with an
  inline message inside the drop zone (do not use a modal alert).
- **Drop zone** accepts drag-and-drop anywhere on the canvas, not just inside the dashes; show the
  drag-over treatment on the card whenever a PDF is dragged over the window.
- **Try a sample** loads a bundled PDF so a first-time user can see the reflow behavior with no file
  of their own.
- **Recents** opens a menu of recent documents; empty on first run — hide the button rather than
  showing an empty menu.
- **Empty-state disabled controls:** Save PDF, Save as…, Undo, Redo, Fit width, Fit page, zoom
  steppers, Blocks. Disabled = the muted treatments above, `aria-disabled`, no hover change,
  still focusable with a tooltip explaining why ("Open a PDF first").
- **Show boxes** toggles the debug overlay; state persists across launches.
- **Transitions:** 120ms ease for hover/background/border; 160ms for the switch knob; the floating
  page cards are the only ambient animation. Pressed state on pill buttons: translateY(2px) and
  drop the hard shadow to `0 1px 0` — the buttons should feel physical.
- **Keyboard:** ⌘O open, ⌘S save, ⌘Z / ⇧⌘Z undo/redo, ⌘+ / ⌘− zoom, ⌘0 fit page. Visible focus
  ring: 3px `rgba(61,139,253,.45)` offset 2px.
- **Responsive:** below ~1080px window width, drop the wordmark subtitle and collapse
  Fit width / Fit page into an overflow "…" menu; keep every remaining target ≥44px. Below
  ~760px the capability cards stack into a column and the drop-zone card goes fluid (max-width
  660px, min padding 24px).

## State Management
- `document: null | { path, filename, pageCount, pages[] }` — `null` drives the empty state.
- `isDragOver: boolean` — drag-over treatment.
- `zoom: number` (default 125) and `fitMode: 'none' | 'width' | 'page'`.
- `undoStack / redoStack` — drive Undo/Redo enablement; the document on disk is never mutated in
  place (Save PDF writes a new file), which is what "Your original stays safe" promises.
- `recents: string[]` — persisted.
- `showBoxes: boolean` — persisted.
- `sampleLoading: boolean` — spinner inside "Try a sample" while the bundled PDF opens.
- Empty state needs no data fetching.

## Design Tokens

**Color**
| Token | Value | Use |
|---|---|---|
| canvas | `#FDF8EC` | document canvas |
| canvas-dot | `rgba(46,42,38,.055)` | dot grid |
| surface | `#FFFFFF` | chrome, cards |
| surface-warm | `#FFFDF7` | action bar |
| surface-sunk | `#F7F3EA` | inset tracks, hover, disabled fill |
| titlebar | `#F6F1E6` | window bar |
| rule-warm | `#F2E7CE` | 2px action-bar underline |
| border | `rgba(46,42,38,.12)` | standard control border |
| border-soft | `rgba(46,42,38,.09)` | card border, disabled border |
| border-strong | `rgba(46,42,38,.14)` | secondary buttons |
| dash | `#D9CFB8` | drop-zone dashes |
| ink | `#2E2A26` | headings |
| ink-body | `#3A3532` | control labels |
| ink-muted | `rgba(46,42,38,.60)` | body copy |
| ink-faint | `rgba(46,42,38,.45)` | captions |
| ink-disabled | `rgba(46,42,38,.32)` | disabled labels |
| blue | `#3D8BFD` (shadow `#2B6FD6`) | primary open action |
| green | `#4FDCA2 → #22C08A` (shadow `#1BA377`) | save |
| purple | `#E7DBFF` / `#7B54D3` | OCR-patch accent |
| butter | `#FCD277`, `#FFF6DF` | secondary paper / accent |
| coral | `#FB8B8B` | destructive / traffic light |
| mint-line | `#A9DFC6` | editable-line hint |
| track-off | `#E3DCCF` | switch off |

**Spacing** 4 · 8 · 10 · 12 · 14 · 18 · 20 · 22 · 24 · 30 · 40 · 44
**Radius** 8 (keycaps) · 12 (paper, small tiles) · 16 (window) · 20 (cards) · 32 (drop zone) · 999 (pills)
**Control heights** 36 (stepper) · 40 (tertiary) · 44 (icon/global) · 46 (action bar) · 56 (hero) — never below 44 for a primary target
**Shadows**
- pill primary: `0 3px 0 <darker>, 0 6px 14px <tint 30%>`
- hero pill: `0 4px 0 <darker>, 0 10px 20px <tint 28%>`
- card: `0 2px 0 rgba(46,42,38,.05)`
- window: `0 8px 24px rgba(46,42,38,.10)`
- paper: `0 6px 14px rgba(46,42,38,.10)` / front `0 10px 20px rgba(46,42,38,.14)`

**Type** — Baloo 2 (600/700/800) for the wordmark and headlines; Nunito (400/600/700/800/900) for
everything else. Scale: 34/800 hero · 26/800 doc title · 19/800 wordmark · 18/800 hero button ·
17/600 subhead · 15.5–15/800 control label · 14.5/800 card title · 13.5/700 switch label ·
12.5/600 caption · 11.5/600 wordmark subtitle. Body line-height 1.5–1.8, headline 1.1–1.2.
If the codebase can't add fonts, substitute a rounded geometric display face and a rounded
humanist UI sans of similar x-height — do not fall back to Inter/Roboto/Arial.

## Assets
- **Fonts:** Nunito and Baloo 2, Google Fonts (loaded by CDN link in the prototype; bundle them
  locally for a desktop app).
- **Icons:** none shipped. The prototype uses typographic stand-ins — map them to the codebase's
  icon set: `＋` plus, `−` minus, `⤓` download/save, `↺` undo, `↻` redo, `?` help,
  `Aa` text settings, `▾` chevron-down, `T` text, `✦` sparkle/magic. Target optical size ~18–20px
  in 44px buttons, 20px in the 38px card tiles.
- **Illustration:** the page-card cluster is pure CSS (rectangles + bars). Reuse it as-is; no image
  needed. No source screenshots or brand assets are included in this bundle.
- **Sample PDF:** needs to be sourced/bundled for "Try a sample".

## Files
- `editpdf-empty-state.html` — the approved design (option 1a): full app shell + empty state.
- `EditPDF Restyle.dc.html` — the original exploration file with all three directions
  (1a Sunny — approved; 1b Cocoa — dark chrome; 1c Big Buttons — guided, chunkiest targets).
  1b/1c also show the **loaded document** view, the paragraph-editing state with the
  "Reflowing to fit ✓" callout, and the OCR-patch highlight — useful reference for the next
  screens, but not part of this handoff's approved scope.
